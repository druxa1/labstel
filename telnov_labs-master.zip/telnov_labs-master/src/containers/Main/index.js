import React from 'react';

const Main = () => (
  <img
    src="https://upload.wikimedia.org/wikipedia/ru/thumb/0/0a/UEFA_Champions_League_logo.svg/440px-UEFA_Champions_League_logo.svg.png"
    alt="ahgf"
  />
);

export default Main;
