import _ from 'lodash';

const initialState = {
  data: [],
  isLoading: true,
  error: null,
};

export default (state = initialState, action) => {
  switch (action.type) {
    default:
      return state;
  }
};
