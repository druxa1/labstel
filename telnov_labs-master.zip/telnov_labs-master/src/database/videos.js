export default [
  {
    id: 1,
    title: 'Как прошла тренировка армейцев перед матчем с "Ромой"',
    videos: 'https://www.youtube.com/watch?v=gWu5kKtKFMg',
  },
  {
    id: 2,
    title: 'Зубков и Коваленко принесли победу сборной Украины U21 над Шотландией U21',
    videos: 'https://www.youtube.com/watch?v=ZEdjeNC_gfs',
  },
  {
    id: 3,
    title: 'Сборная Украины продолжает подготовку к матчу против Чехии',
    videos: 'https://www.youtube.com/watch?v=-xxdGQ7ljwU',
  },
  {
    id: 4,
    title: 'UEFA Nations League | UKRAINE 1 - 0 CZECH REPUBLIC | Шевченко',
    videos: 'https://www.youtube.com/watch?v=AnzR0HMgVzA',
  },
  {
    id: 5,
    title: 'Франция - Германия, Украина - Чехия / Прогноз на футбол /Экспресс на футбол 16.10.2018 г',
    videos: 'https://www.youtube.com/watch?v=ESvJW1X9DKU',
  },
  {
    id: 6,
    title: 'Италия - Украина прогноз и обзор Товарищеский матч футбол спорт',
    videos: 'https://www.youtube.com/watch?v=h2x6vpyaUo8',
  },
  {
    id: 7,
    title: 'Головна команда (Италия - Украина) от 10.10.2018 (21:00)',
    videos: 'https://www.youtube.com/watch?v=Rg-jlXlV8Fg',
  },
  {
    id: 8,
    title: 'Матч Украина-Чехия состоится при заполненных трибунах',
    videos: 'https://www.youtube.com/watch?v=5PvdVmZZTXw',
  },
  {
    id: 9,
    title: 'Италия - Украина прогноз Артема Франкова | Товарищеский матч | Ставки и прогнозы',
    videos: 'https://www.youtube.com/watch?v=U5mw5cLIyUI',
  },
  {
    id: 10,
    title: 'ИТАЛИЯ - УКРАИНА 1-1/ ПРОГНОЗ И СТАВКА НА ФУТБОЛ / ТОВАРИЩЕСКИЙ МАТЧ',
    videos: 'https://www.youtube.com/watch?v=C2_-8PSl9_M',
  },
  {
    id: 11,
    title: 'Эксперты – о матче Украина – Чехия',
    videos: 'https://www.youtube.com/watch?v=EXoDHyx8N5g',
  },
  {
    id: 12,
    title: 'Украина - Чехия: последние новости перед матчем',
    videos: 'https://www.youtube.com/watch?v=dTYpDcFHp2g',
  },
  {
    id: 13,
    title: 'FIFA 19 СБОРНАЯ УКРАИНЫ',
    videos: 'https://www.youtube.com/watch?v=EVgm3B6kM08',
  },
  {
    id: 14,
    title: 'Гол! Руслан Малиновский, 62 мин., Украина',
    videos: 'https://www.youtube.com/watch?v=uxnTI0lMCmc',
  },
  {
    id: 15,
    title: 'Сборная (Италия - Украина) от 10.10.2018 (23:40)',
    videos: 'https://www.youtube.com/watch?v=QWsvZ8fgz8Q',
  },
  {
    id: 16,
    title: 'ПРОГНОЗ ФРАНЦИЯ - ГЕРМАНИЯ / УКРАИНА - ЧЕХИЯ',
    videos: 'https://www.youtube.com/watch?v=614CQiTkPGE',
  },
  {
    id: 17,
    title: 'ФУТБОЛ. МАТЧ ИТАЛИЯ - УКРАИНА. В КОМАНДЕ ШЕВЧЕНКО МНОГО ВЫБЫВШИХ',
    videos: 'https://www.youtube.com/watch?v=h7w7G9ka-2M',
  },
  {
    id: 18,
    title: 'Анонс. Лига Наций УЕФА. Украина - Чехия',
    videos: 'https://www.youtube.com/watch?v=BMwv6Adf14Y',
  },
  {
    id: 19,
    title: 'ГРЯЗНЫЙ СЕРХИО РАМОС ● СКОУЛЗ: "МЕССИ ЛУЧШЕ РОНАЛДУ"',
    videos: 'https://www.youtube.com/watch?v=hG2c_sqMX1g',
  },
  {
    id: 20,
    title: 'Италия - Украина / прогноз и ставки на футбол 10.10.2018',
    videos: 'https://www.youtube.com/watch?v=rJ1Bi8j7imA',
  },
];
